The game consists of two different types of enemies. Both with damage the player on contact. 
The player can fire "high" or "low" bullets at the enemies. Hitting the small ones will only move them out of the way
while hitting the large ones in the head will kill them. The player's health is displayed on the screen in the form
on little heart icons. Enemies run towards the player when the player comes within a certain distance and stop moving once
the player passes them (to make the level easier). Players will repawn in the air, falling down to the start point, after death.