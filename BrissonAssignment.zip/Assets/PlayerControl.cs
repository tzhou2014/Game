﻿using UnityEngine;
using System.Collections;

public class PlayerControl : MonoBehaviour {

	Animator anim;
	bool inAir = false;
	int count = 0;
	public Rigidbody bullet;
	public GameObject text1;
	public GameObject text2;
	RaycastHit hit;
	public float direction = 1;
	public GameObject thecamera;

	// Use this for initialization
	void Start () {

		anim = GetComponent<Animator>();
	}
	

	// Update is called once per frame
	void Update () {
		rigidbody.freezeRotation = true;
		float input = Input.GetAxis ("Horizontal");
		float z = input * Time.deltaTime * 7;
		anim.SetFloat("Speed", Mathf.Abs(input));
		if (z < 0 && direction == 1 && transform.position.y < 25) {
			transform.Rotate (0,180,0,Space.World);
			thecamera.transform.RotateAround(transform.position,Vector3.up,180);
			direction = -1;
				}
		else if (z >0 && direction == -1 && transform.position.y < 25){
			transform.Rotate (0,180,0, Space.World);
			thecamera.transform.RotateAround(transform.position,Vector3.up,180);
			direction = 1;
		}

			
		if (Input.GetKey ("up")) {
						if (inAir && count < 30)
						{
							transform.Translate (0, 8 * Time.deltaTime, 0);
							anim.SetBool("Jumping",true);
						}
						else if (!inAir){
									inAir = true;
									transform.Translate (0, 8 * Time.deltaTime, 0);
								}
								
						count += 1;
				} 
		if (z > 0 || z < 0  && transform.position.y < 25) {	
			transform.Translate (0, 0, z*direction);						
				} 

		if (Input.GetKeyDown("x")) {
			Rigidbody clone;
			Vector3 bulletPlace = new Vector3(transform.position.x,transform.position.y+1,transform.position.z-(0.7f*direction));
			clone = Instantiate(bullet, bulletPlace, transform.rotation) as Rigidbody;
			clone.transform.RotateAround (clone.transform.position, new Vector3(1,0,0), 90f);
			if (direction < 0)
			{
				clone.velocity = transform.TransformDirection(0,-10,-35);
			}
			else
			{
			}

				clone.velocity = transform.TransformDirection(0,-10,35);
		}
		if (Input.GetKeyDown("c")) {
			Rigidbody clone;
			Vector3 bulletPlace = new Vector3(transform.position.x,transform.position.y+1.5f,transform.position.z-(0.7f*direction));
			clone = Instantiate(bullet, bulletPlace, transform.rotation) as Rigidbody;
			clone.transform.RotateAround (clone.transform.position, new Vector3(1,0,0), 90f);
			if (direction < 0)
			{
				clone.velocity = transform.TransformDirection(0,-10,-30);
			}
			else
			{
			}

				clone.velocity = transform.TransformDirection(0,0,30);
		}

	}

	void OnCollisionEnter(Collision collision)
	{
		if (collision.gameObject.layer==8) {
						anim.SetBool("Jumping",false);
						inAir = false;
						count = 0;
				}
	}

	
}

